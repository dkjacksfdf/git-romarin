import java.util.Scanner;

public class Institui��oDeEnsino {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int i;
		String nomealuno;
		double nota, media = 0, somamedia = 0;

		String msg1 = "";
		String msg2 = "";

		System.out.println("Informe o nome do professor:");
		String prof = sc.next();
		System.out.println("Digite o nome da turma:");
		String turma = sc.next();
		System.out.println("Informe a disciplina aplicada:");
		String disc = sc.next();
		System.out.println("Qual o n�mero de alunos na turma?");
		int numalunos = sc.nextInt();
		System.out.println("Qual o n�mero de avalia��es realizadas na turma?");
		int numaval = sc.nextInt();

		for (i = 0; i < numalunos; i++) {
			System.out.println("Nome do aluno(a):");
			nomealuno = sc.next();

			for (int j = 1; j <= numaval; j++) {
				System.out.println("Nota do aluno(a):");
				nota = sc.nextDouble();
				
				msg1 += "\nNota " + j + ": " + nota;
				somamedia += nota;

			}

			media = somamedia / numaval;
			msg2 += "\nAluno(a): " + nomealuno + "\n" + msg1 + "\nA m�dia � " + media + "\n";
			if (media < 5) {
				msg2 += "Reprovado\n";
			} else if (media < 7) {
				msg2 += "Exame\n";
			} else {
				msg2 += "Aprovado\n";
			}
			somamedia = 0;
			msg1 = "";

		}
		sc.close();
		
		System.out.println("Nome do professor(a): " + prof + "\nNome da turma: " + turma + "\nA disciplina aplicada foi: "
				+ disc + "\nO numero de alunos na turma � de: " + numalunos + "\nO total de avalia��es foi de: "
				+ numaval + "\nAs notas e nomes dos alunos: " + msg2);
		
	}
}
