import java.util.Scanner;

public class Institui��oDeEnsino {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int i;
		String nomealuno;
		double nota,media;
		String msg1 = "";
		String msg2 = "Aluno:";
		System.out.println("Informe o nome do professor:");
		String prof = sc.next();
		System.out.println("Digite o nome da turma:");
		String turma = sc.next();
		System.out.println("Informe a disciplina aplicada:");
		String disc = sc.next();
		System.out.println("Qual o n�mero de alunos na turma?");
		int numalunos = sc.nextInt();
		System.out.println("Qual o n�mero de avalia��es realizadas na turma?");
		int numaval = sc.nextInt();
		for (i = 0; i < numalunos; i++) {
			System.out.println("Nome do aluno:");
			nomealuno = sc.next();
			for (int j = 0; j < numaval; j++) {
				System.out.println("Nota aluno:");
				nota = sc.nextDouble();
				msg1 += "\n"+nota;
				//opera��o
			}
			msg2 += "\n"+nomealuno+":\n"+msg1;
			
			
		}

	}
}
